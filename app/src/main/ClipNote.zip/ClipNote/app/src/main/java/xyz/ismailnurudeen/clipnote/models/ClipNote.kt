package xyz.ismailnurudeen.clipnote.models

import java.util.*

data class ClipNote(val id: String, val text: String, val createdAt: String,val updatedAt:String)