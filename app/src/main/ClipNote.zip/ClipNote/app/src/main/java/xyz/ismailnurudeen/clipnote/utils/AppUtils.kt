package xyz.ismailnurudeen.clipnote.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import xyz.ismailnurudeen.clipnote.models.ClipNote
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class AppUtils(private val context: Context) {
    val prefsManager: PrefsManager = PrefsManager(context)

    fun readFromClipBoard(): CharSequence {
        val cbm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (cbm.hasPrimaryClip()) {
            val cd = cbm.primaryClip
            return cd!!.getItemAt(0).text
        }
        return ""
    }

    fun copyToClipBoard(txt: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val cd = ClipData.newPlainText("clip", txt)
        cm.primaryClip = cd
    }

    fun saveNote(txt: String): Boolean {
        val currentTime = formatDate(Calendar.getInstance().time)
        val notesList = prefsManager.clipNotes ?: ArrayList()
        notesList.add(ClipNote(UUID.randomUUID().toString(), txt, currentTime, currentTime))
        prefsManager.clipNotes = notesList
        return true
    }

    fun updateNote(index: Int, txt: String): Boolean {
        val currentTime = formatDate(Calendar.getInstance().time)
        val notesList = prefsManager.clipNotes ?: ArrayList()
        val clipNote = notesList[index]
        val note = ClipNote(clipNote.id, txt, clipNote.createdAt, currentTime)
        notesList.removeAt(index)
        notesList.add(index, note)
        prefsManager.clipNotes = notesList
        return true
    }

    fun deleteNote(index: Int): Boolean {
        val currentTime = formatDate(Calendar.getInstance().time)
        val notesList = prefsManager.clipNotes ?: ArrayList()
        notesList.remove(notesList[index])
        prefsManager.clipNotes = notesList
        return true
    }

    fun deleteAllNotes(): Boolean {
        val notesList = prefsManager.clipNotes ?: ArrayList()
        notesList.clear()
        prefsManager.clipNotes = notesList
        return true
    }

    fun formatDate(date: Date?, format: String = "dd/MM/yyyy hh:MM a"): String {
        return if (date != null) SimpleDateFormat(format, Locale.getDefault()).format(date)
        else ""

    }

    @Throws(ParseException::class)
    fun stringToDate(dateString: String, format: String = "dd/MM/yyyy"): Date? =
        SimpleDateFormat(format, Locale.getDefault()).parse(dateString)

    fun shareNote(txt: String) {
        val otherIntent = Intent(Intent.ACTION_SEND)
        otherIntent.type = "text/plain"
        otherIntent.putExtra(Intent.EXTRA_TEXT, txt)
        context.startActivity(Intent.createChooser(otherIntent, "Share Note With..."))
    }
}