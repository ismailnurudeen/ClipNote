package xyz.ismailnurudeen.clipnote

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.Toast
import com.chauthai.swipereveallayout.SwipeRevealLayout
import com.chauthai.swipereveallayout.ViewBinderHelper
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.item_clip_note.view.*
import org.greenrobot.eventbus.Subscribe
import xyz.ismailnurudeen.clipnote.events.EditEvent
import xyz.ismailnurudeen.clipnote.models.ClipNote
import xyz.ismailnurudeen.clipnote.utils.AppUtils
import xyz.ismailnurudeen.clipnote.utils.PrefsManager
import java.util.*
import kotlin.collections.ArrayList


class MainActivity : AppCompatActivity() {
    lateinit var appUtils: AppUtils
    lateinit var prefsManager: PrefsManager
    var clipList: ArrayList<ClipNote> = ArrayList()
    lateinit var notesAdapter: MainAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        appUtils = AppUtils(this)
        prefsManager = PrefsManager(this)

        setupNotesRv()
        setupNotes()

        home_add_note.setOnClickListener {
            val editIntent = Intent(this, EditActivity::class.java)
            startActivity(editIntent)
        }
        val optionsPopup = PopupMenu(this, home_options)
        optionsPopup.inflate(R.menu.options_popup)

        optionsPopup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menu_change_layout -> {
                    Toast.makeText(this@MainActivity, "Change Layout", Toast.LENGTH_SHORT).show()
                }
                R.id.menu_delete_all_notes -> {
                    showDeleteAllConfirmationDialog()
                }
            }
            true
        }

        home_options.setOnClickListener {
            optionsPopup.show()
        }
        home_info.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

    }

    private fun setupNotesRv() {
        notesAdapter = MainAdapter(this, clipList)
        main_rv.adapter = notesAdapter
        notesAdapter.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
            override fun onChanged() {
                if (notesAdapter.itemCount != 0) {
                    main_rv.visibility = View.VISIBLE
                    no_notes_view.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "We have notes", Toast.LENGTH_SHORT).show()
                } else {
                    no_notes_view.visibility = View.VISIBLE
                    main_rv.visibility = View.GONE
                    Toast.makeText(
                            this@MainActivity,
                            "${main_rv.adapter?.itemCount} Notes Visible!",
                            Toast.LENGTH_LONG
                    ).show()
                }
                super.onChanged()
            }
        })
    }

    private fun setupNotes() {
        clipList = prefsManager.clipNotes ?: ArrayList()
        if (clipList.isNullOrEmpty()) {
            no_notes_view.visibility = View.VISIBLE
        } else {
            notesAdapter.notifyDataSetChanged()
        }
    }

    private fun showDeleteAllConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Delete All Notes")
        builder.setMessage("Are you sure you want to delete all notes?")
        builder.setNegativeButton("No") { dialog, which ->
            dialog.dismiss()
        }
        builder.setPositiveButton("Yes") { dialog, which ->
            if (appUtils.deleteAllNotes()) {
                clipList.clear()
                Toast.makeText(this, "All Notes Deleted!", Toast.LENGTH_SHORT).show()
                main_rv.adapter?.notifyDataSetChanged()
            }
        }
        builder.create().show()
    }

    @Subscribe
    public fun onEvent(event: EditEvent) {
        setupNotes()
    }

    inner class MainAdapter(
            private val context: Context,
            private val clipNotes: ArrayList<ClipNote>
    ) :
            RecyclerView.Adapter<MainAdapter.ClipHolder>() {
        private val viewBinderHelper = ViewBinderHelper()

        init {
            viewBinderHelper.setOpenOnlyOne(true)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClipHolder =
                ClipHolder(LayoutInflater.from(context).inflate(R.layout.item_clip_note, parent, false))

        override fun getItemCount(): Int = clipNotes.size

        override fun onBindViewHolder(holder: ClipHolder, pos: Int) {
            viewBinderHelper.bind(holder.swipeRevealLayout, UUID.randomUUID().toString())
            holder.bind(clipNotes[pos])
        }

        inner class ClipHolder(private val iv: View) : RecyclerView.ViewHolder(iv) {
            var swipeRevealLayout: SwipeRevealLayout = iv.swipe_layout

            fun bind(clipNote: ClipNote) {
                iv.text.text = clipNote.text
                swipeRevealLayout.clip_item_card.setOnClickListener {
                    val viewIntent = Intent(context, ViewNoteActivity::class.java)
                    viewIntent.putExtra("EXTRA_NOTE_ID", adapterPosition)
                    context.startActivity(viewIntent)
                }
                iv.item_note_copy.setOnClickListener {
                    appUtils.copyToClipBoard(clipNote.text)
                    Toast.makeText(context, "Copied to Clipboard", Toast.LENGTH_SHORT).show()
                }
                iv.item_note_delete.setOnClickListener {
                    showDeleteConfirmationDialog(adapterPosition)
                }
            }

            private fun showDeleteConfirmationDialog(index: Int) {
                val builder = AlertDialog.Builder(context)
                builder.setTitle("Delete Note")
                builder.setMessage("Are you sure you want to delete this note?")
                builder.setNegativeButton("No") { dialog, which ->
                    dialog.dismiss()
                }
                builder.setPositiveButton("Yes") { dialog, which ->
                    if (appUtils.deleteNote(index)) {
                        clipNotes.removeAt(index)
                        Toast.makeText(context, "Deleted!", Toast.LENGTH_SHORT).show()
                        notifyDataSetChanged()
                    }
                }
                builder.create().show()
            }
        }
    }
}
