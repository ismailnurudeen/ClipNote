package xyz.ismailnurudeen.clipnote.events

class EditEvent {
    var noteSaved = false
    var noteUpdated = false
    var noteDeleted = false
}